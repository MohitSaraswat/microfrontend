import { Component, ChangeDetectorRef, Inject } from '@angular/core'
import e from '../event-bus'

@Component({
  selector: 'AngularApp',
  template: `
    <div style="margin-top: 100px;">
    <button (click)="angularToReact()">send message from Angular to React</button>
      <h1>This component is written in Angular</h1>
      <p>{{messageFromReact}}</p>
      <p>{{response}}</p>
		</div>
	`,
})
export default class AngularApp {
  messageFromReact: string = "Message From React will appear here.."
  response: string = "This will change when React respond to Angular Message.."

  constructor(@Inject(ChangeDetectorRef) private changeDetector: ChangeDetectorRef) {}

  ngAfterContentInit() {
    e.on('reactToAngular', message => {
      this.messageFromReact = message.text
      this.changeDetector.detectChanges()
      this.returnMessageToReactWhenReceived()
    })
    e.on('reactReasponseToAngular', message => {
      this.response = message.text
      this.changeDetector.detectChanges()
      this.angularToReact()
    })
  }

  angularToReact() {
    e.emit('angularMessageToReact', { text: 'ANGULAR MESSAGED REACT - Hello from Angular to React !' });
  }

  returnMessageToReactWhenReceived() {
    e.emit('angularResponseToReact', { text: 'ANGULAR RESPOND TO REACT - Hello from Angular to React !' })
  }
}
