import React from 'react'
import e from '../event-bus'

export default class Root extends React.Component {
  constructor(props) {
    super(props)

    this.state = {
      message: 'This will change when Angular respond to React Message..',
      angularToReact: 'Message From Angular will appear here..'
    }

    this.messageHandler = this.messageHandler.bind(this)
    this.angularToReactHandler = this.angularToReactHandler.bind(this)
  }

  componentDidMount() {
    e.on('angularMessageToReact', this.angularToReactHandler)
    e.on('angularResponseToReact', this.messageHandler)
  }

  componentDidUnmount() {
    e.off('angularMessageToReact', this.angularToReactHandler)
    e.off('angularResponseToReact', this.messageHandler)
  }

  messageHandler(message) {
    this.setState({
      message: message.text
    })
  }

  angularToReactHandler(message) {
    this.setState({
      angularToReact: message.text
    })
    e.emit("reactReasponseToAngular", { text: 'REACT RESPOND TO ANGULAR - Hello from React to Angular !' })
  }

  sendMessageFromReactToAngular() {
    e.emit('reactToAngular', { text: 'REACT MESSAGED ANGULAR - Hello from React to Angular !' })
  }

  render() {
    return (
      <div style={{marginTop: '10px'}}>
        <h1>This component is written in React</h1>
        <p>
          <button onClick={this.sendMessageFromReactToAngular}>
            Send a message from React to Angular
          </button>
        </p>
        <p>
          {this.state.message}
        </p>
        <p>
          {this.state.angularToReact}
        </p>
      </div>
    )
  }
}
